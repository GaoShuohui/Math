syms M m l n h h1 t F d x
M=3.6;
m=0.27;
%n=8;
%��lΪ��֪
l=1.0;
%F=80;
h=0.1*l;%h<<l
h1=0.4;
d=0.6;
%l=d/(2*sin(pi/n));
n=pi/asin(d/2/l);
%t1=(2*(h1+h-M*9.8*l/(n*F))/9.8)^1/2;
%t2=pi/2*(M*l/(n*F))^1/2;
%x=(2*(h1+h-M*9.8*l/(n*F))/9.8)^1/2;
%h=(1323*pi - 200*x*n*sin(pi/n) + 5292)/(500*x*n*sin(pi/n));
%solve(M*(M*9.8*l/n-h*F)^2==m^2*2*9.8*l/n*(F*h1+F*h-M*9.8*l/n))
solve(M*(M*9.8*l/n-h*x)^2==m^2*2*9.8*l/n*(x*(h1+h)-M*9.8*l/n))