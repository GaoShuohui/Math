function fy=problem21(t,x)
C=0.129;
D=-2;
A=3.6*(0.04+2/3*0.11^2)/2;
fy=[x(2);(C*cos(x(1))+D*sin(x(1)))/A];
end