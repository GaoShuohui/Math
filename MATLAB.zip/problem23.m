function fy=problem23(t,x)
C=4*1.1/17*cos(3*pi/8);
D=-0.4*(160*cos(pi/8)*cos(pi/8)+170*cos(3*pi/8)*cos(3*pi/8));
A=3.6*(0.04+2/3*0.11^2)/2;
fy=[x(2);(C*cos(x(1))+D*sin(x(1)))/A];
end