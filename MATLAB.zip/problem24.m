function fy=problem24(t,x)
C=32;
D=-80;
A=3.6*(0.04+2/3*0.11^2)/2;
fy=[x(2);(C*cos(x(1))+D*sin(x(1)))/A];
end